using System.Numerics;

namespace TemperaturConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Covert_MouseClick(object sender, MouseEventArgs e)
        {
            if (double.TryParse(Temperature.Text, out double input))
                if (Celsius.Checked)
                {
                    input = Math.Round(input, 2);
                    double result = (input * 1.8) + 32; 
                                                        
                    Result.Text = result.ToString("F2") + " �F"; 

                }
                else if (Fehrenheit.Checked)
                {
                    input = Math.Round(input, 2); 
                    double result = (input - 32) / 1.8; 
                                                       
                    Result.Text = result.ToString("F2") + " �C"; 
                }
                else
                {
                    MessageBox.Show("Please select a conversion type (Celsius or Fahrenheit).");
                }
            if (string.IsNullOrEmpty(Temperature.Text))
            {
                MessageBox.Show("Please type a value");
            }
           
        }

        private void Covert_Click(object sender, EventArgs e)
        {

        }
    }
}
