﻿namespace TemperaturConverter
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Temperature = new TextBox();
            label1 = new Label();
            label2 = new Label();
            Covert = new Button();
            Result = new TextBox();
            Celsius = new RadioButton();
            Fehrenheit = new RadioButton();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Temperature
            // 
            Temperature.BackColor = Color.White;
            Temperature.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Italic, GraphicsUnit.Point, 161);
            Temperature.Location = new Point(27, 44);
            Temperature.Margin = new Padding(3, 4, 3, 4);
            Temperature.Multiline = true;
            Temperature.Name = "Temperature";
            Temperature.Size = new Size(135, 37);
            Temperature.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 161);
            label1.Location = new Point(27, 11);
            label1.Name = "label1";
            label1.Size = new Size(117, 23);
            label1.TabIndex = 3;
            label1.Text = "Temperature:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 161);
            label2.Location = new Point(27, 101);
            label2.Name = "label2";
            label2.Size = new Size(64, 23);
            label2.TabIndex = 4;
            label2.Text = "Result:";
            // 
            // Covert
            // 
            Covert.FlatAppearance.MouseOverBackColor = Color.DarkGray;
            Covert.Location = new Point(323, 153);
            Covert.Margin = new Padding(3, 4, 3, 4);
            Covert.Name = "Covert";
            Covert.Size = new Size(118, 38);
            Covert.TabIndex = 5;
            Covert.Text = "Convert";
            Covert.UseVisualStyleBackColor = true;
            Covert.MouseClick += Covert_MouseClick;
            // 
            // Result
            // 
            Result.BackColor = Color.White;
            Result.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Italic, GraphicsUnit.Point, 161);
            Result.Location = new Point(27, 139);
            Result.Margin = new Padding(3, 4, 3, 4);
            Result.Multiline = true;
            Result.Name = "Result";
            Result.ReadOnly = true;
            Result.Size = new Size(135, 37);
            Result.TabIndex = 6;
            // 
            // Celsius
            // 
            Celsius.AutoSize = true;
            Celsius.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 161);
            Celsius.Location = new Point(187, 45);
            Celsius.Name = "Celsius";
            Celsius.Size = new Size(91, 31);
            Celsius.TabIndex = 7;
            Celsius.TabStop = true;
            Celsius.Text = "Celsius";
            Celsius.UseVisualStyleBackColor = true;
            Celsius.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // Fehrenheit
            // 
            Fehrenheit.AutoSize = true;
            Fehrenheit.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 161);
            Fehrenheit.Location = new Point(187, 93);
            Fehrenheit.Name = "Fehrenheit";
            Fehrenheit.Size = new Size(130, 31);
            Fehrenheit.TabIndex = 8;
            Fehrenheit.TabStop = true;
            Fehrenheit.Text = "Fahrenheit";
            Fehrenheit.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.forecast_;
            pictureBox1.BackgroundImageLayout = ImageLayout.Center;
            pictureBox1.Location = new Point(323, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(116, 144);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AllowDrop = true;
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(451, 204);
            Controls.Add(pictureBox1);
            Controls.Add(Fehrenheit);
            Controls.Add(Celsius);
            Controls.Add(Result);
            Controls.Add(Covert);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Temperature);
            Cursor = Cursors.Hand;
            Font = new Font("Comic Sans MS", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 161);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Temperature Converter 00.01";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox Temperature;
        private Label label1;
        private Label label2;
        private Button Covert;
        private TextBox Result;
        private RadioButton Celsius;
        private RadioButton Fehrenheit;
        private PictureBox pictureBox1;
    }
}
